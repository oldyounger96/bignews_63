Correct Version here https://github.com/josecebe/twbs-pagination
